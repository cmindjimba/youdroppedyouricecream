using System.Collections.Generic;
using System.Linq;
using System;
using UnityEngine;

public class GameController : MonoBehaviour
{
    public static char Letter = 'a';

    static int _correctAnswers = 5;
    static int _correctClicks;

    private void OnEnable()
    {
        GenerateBoard();
        UpdateDisplay();
    }

    private static void GenerateBoard()
    {
        var clickables = FindObjectsOfType<ClickableLetter>();
        int count = clickables.Length;

        List<char> charsList = new List<char>();

        for (int i = 0; i < _correctAnswers; i++)
            charsList.Add(Letter);

        for (int i = _correctAnswers; i < count; i++)
        {
            var chosenLetter = ChooseInvalidRandomLetter();
            charsList.Add(chosenLetter);
        }

        charsList = charsList.OrderBy(t => UnityEngine.Random.Range(0, 10000)).ToList();

        for (int i = 0; i < count; i++)
        {
            clickables[i].SetLetter(charsList[i]);
        }

        FindObjectOfType<RemainingCounterText>().SetRemaining(_correctAnswers - _correctClicks);
    }

    internal static void HandleCorrectLetterClick()
    {
        _correctClicks++;

        FindObjectOfType<RemainingCounterText>().SetRemaining(_correctAnswers - _correctClicks);

        if(_correctClicks >= _correctAnswers)
        {
            Letter++;

            UpdateDisplay();

            _correctClicks = 0;
            GenerateBoard();
        }
    }

    private static void UpdateDisplay()
    {
        foreach (var displayLetter in FindObjectsOfType<DisplayLetter>())
        {
            displayLetter.SetLetter(Letter);
        }
    }

    private static char ChooseInvalidRandomLetter()
    {
        int a = UnityEngine.Random.Range(0, 26);
        var _randomLetter = (char)('a' + a);

        while (_randomLetter == Letter)
        {
            a = UnityEngine.Random.Range(0, 26);
            _randomLetter = (char)('a' + a);
        }

        return _randomLetter;
    }
}